@extends('layouts.app')
@section('content')
    <h1>Packagetest Message</h1>
    {{$msg}}
@endsection